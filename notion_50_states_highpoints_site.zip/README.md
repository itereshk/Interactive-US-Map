# 50 States + High Point Atlas

## Publish in Notion with GitHub Pages
1. Create a GitHub account if necessary, then create a new **public** repository (e.g., `state-highpoint-atlas`).
2. Upload `index.html` from this folder to the repository root and commit.
3. Open repository **Settings → Pages**; choose **Deploy from a branch**, branch **main**, folder **/(root)**, then save.
4. Once the site is published, open its HTTPS address (normally `https://YOUR-USERNAME.github.io/state-highpoint-atlas/`).
5. In Notion type `/embed`, paste this published URL, and resize the embed to fit.

## Save and sync details
- Clicking/checking a state saves immediately to the **browser's localStorage** under `highpoint-atlas-v1`.
- Notes and dates are also saved in that browser.
- Notion does **not** keep these entries in a Notion database, and a separate browser/device may show an empty tracker.
- Embedded content may have storage restrictions in private browsing or certain security settings; verify that changes persist after a page reload.
- Use **Export backup** to download your JSON data and **Import backup** to restore it on another browser or device. Import replaces existing progress on that browser.
- Keep your JSON backup somewhere safe. If browser data is wiped, progress can be lost without one.
- For automatic cross-device sync, a hosted backend with authentication (e.g. Supabase or Firebase) must be added. This starter version deliberately does not require or store any cloud API credentials.

## What is tracked
Each of the 50 states has distinct checkboxes for **State visited** and **High point completed**, with separate dates and notes. Map modes: Combined, Visited, High points. Green in combined mode means both completed, gold indicates a completed high point only, blue means visited only, and slate means neither.

## Technical notes
The page loads public map geometry and JS libraries from jsDelivr when online. If these resources cannot load, an interactive tile-grid map appears automatically. Progress functionality remains usable in either view.
